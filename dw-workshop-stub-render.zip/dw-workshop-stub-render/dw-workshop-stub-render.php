<?php
/**
 * Plugin Name: DreamWood Workshop Stub Render
 * Description: Renders the Education for Couples workshop HTML stub as an isolated responsive iframe shortcode.
 * Version: 1.0.0
 */
if (!defined('ABSPATH')) { exit; }
add_shortcode('dw_workshop_stub', function () {
    $file = __DIR__ . '/workshop.html';
    if (!is_readable($file)) { return ''; }
    $html = file_get_contents($file);
    $srcdoc = esc_attr($html);
    ob_start();
    ?>
    <style>
      body.page-id-888 .elementor-location-header,
      body.page-id-888 .elementor-location-footer,
      body.page-id-888 .page-header,
      body.page-id-888 .entry-title { display:none !important; }
      body.page-id-888 { margin:0 !important; background:#fbf9f6; }
      body.page-id-888 .site-main,
      body.page-id-888 .site-content,
      body.page-id-888 .page-content,
      body.page-id-888 .elementor-section-wrap { padding:0 !important; margin:0 !important; max-width:none !important; }
      .dw-workshop-frame-wrap { width:100%; overflow:hidden; background:#fbf9f6; }
      .dw-workshop-frame { width:100%; min-height:100vh; border:0; display:block; background:#fbf9f6; }
    </style>
    <div class="dw-workshop-frame-wrap">
      <iframe class="dw-workshop-frame" title="DreamWood Workshop" scrolling="no" loading="eager" srcdoc="<?php echo $srcdoc; ?>"></iframe>
    </div>
    <script>
      (function(){
        var frame = document.currentScript.previousElementSibling.querySelector('iframe');
        function onMessage(event){
          if (!event.data || !event.data.dwWorkshopHeight) return;
          frame.style.height = Math.ceil(event.data.dwWorkshopHeight) + 'px';
        }
        window.addEventListener('message', onMessage);
      })();
    </script>
    <?php
    return ob_get_clean();
});
